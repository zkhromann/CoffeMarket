//
//  CoffeeeApp.swift
//  Coffeee
//
//  Created by Роман Захаров on 10.02.2023.
//

import SwiftUI
let screen = UIScreen.main.bounds

@main
struct CoffeeeApp: App {
    var body: some Scene {
        WindowGroup {
            AuthView()
                
        }
    }
}
